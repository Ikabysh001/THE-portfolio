import pygame
import random

pygame.init()
gravity=0.7

screen_width, screen_height = 927,575
screen=pygame.display.set_mode((screen_width,screen_height))
background=pygame.image.load("images/bg.jpg")
background=pygame.transform.scale(background,(screen_width,screen_height))

player_image=pygame.image.load("images/good bird.png")
orig_x = 171
orig_y = 122
player_scale = 0.3
player_image=pygame.transform.scale(player_image,(orig_x*player_scale,orig_y*player_scale))

def draw_player(x,y):
    screen.blit(player_image,(x,y))
    
playerx = 250
playery = 400

enemy_image=pygame.image.load("images/pipe.png")
enemyx = 900
enemyy = 300
enemy_image = pygame.transform.scale(enemy_image,(50,280))
fl_enemy_image =pygame.transform.rotate(enemy_image,180)

screen=pygame.display.set_mode((screen_width,screen_height))


def draw_pipe(x,y,gap,gap2):
    screen.blit(fl_enemy_image,(x,y-gap))
    screen.blit(enemy_image,(x,y-gap2))

    
done=False
g = random.randint(450,550)
g2 = random.randint(100,200)
while True:
    screen.blit(background,(0,0))
    draw_player(playerx,playery)
    draw_pipe(enemyx,enemyy,g,g2)

    enemyx=enemyx-1
    playery=playery+gravity

    if enemyx<0:
        enemyx=900
        g = random.randint(450,550)
        g2= random.randint(450,550)

        

    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP or event.key == pygame.K_a:
                playery=playery-60

        
    pygame.display.update()
